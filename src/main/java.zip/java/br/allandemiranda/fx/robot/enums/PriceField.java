package br.allandemiranda.fx.robot.enums;

/**
 * Price Constants
 * ENUM_STO_PRICE
 */
public enum PriceField {
  STO_LOWHIGH,
  STO_CLOSECLOSE
}
