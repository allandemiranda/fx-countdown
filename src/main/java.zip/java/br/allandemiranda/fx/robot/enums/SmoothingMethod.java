package br.allandemiranda.fx.robot.enums;

/**
 * Smoothing Methods
 * ENUM_MA_METHOD
 */
public enum SmoothingMethod {
  MODE_SMA,
  MODE_EMA,
  MODE_SMMA,
  MODE_LWMA
}
